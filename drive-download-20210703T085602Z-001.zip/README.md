# Alarm

The most insane alarm clock you've ever seen. Not only does it play the most annoying sound ever, it also requires solving a sudoku puzzle to turn it off.

## Usage

Start alarm:

```
npm start
```

You can control the alarm clock by opening the URL at the bottom of the window on another device.

Personally I run this app on a Raspberry PI hooked up to a monitor and a keyboard, but any computer will work.

## License

GPL v3
